// task 1

const wishes = ["Hello!", "How are you?", "Hi, guys!"];

alert(wishes[0]);

// task 2

const robotFirst = {name:"Roby", color:"orange", type:"male, female"};

const robotSecond = {name:"Ruby", color:"pink", type:"male, female"};

let frase = `Hello, ${robotSecond.name}!`;

console.log(frase) 

// validate form

// const body = document.querySelector("body");

// const form = document.querySelector("#robotForm");

// form.addEventListener("submit", validateForm);

// const nameR = document.querySelector("h4#name");

// const name = form.querySelector("input[name = 'name']");

// const validTextarea = form.querySelector("textarea");


//  function validateForm(){

	
//  	if (name.value && validTextarea.value){
//  		const messege = document.createElement("span");

// 		messege.textContent = alert((name.value, validTextarea.value));

//  		nameR.appendChild ("messege");

//  		event.preventDefault();

//  		name.value ="";
// 	}
// 		else {
// 			alert("The form is not full!");
// 		}

// }

	


	