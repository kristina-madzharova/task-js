// task 3

let numbers = [ -21, -12, -11, -9, -5, 0, 1, 6, 17, 20, 22 ];

positiveNum = numbers.filter(checkNumbers);

function checkNumbers(positiveNum) {
  return positiveNum > 0;
}

console.log(positiveNum);


// task 4

let products = [
    { product: "Shirt", price: 10 },
    { product: "Laptop", price: 2400 },
    { product: "Bike", price: 450 },
    { product: "Chair", price: 150 },
    { product: "Phone", price: 1500 },
    { product: "Shoes", price: 60 },
    { product: "Car", price: 25000 },
    { product: "Coffe Machine", price: 500 }
];

let cheap = [];

let normal = [];

let expensive = [];

let moreExpensive = [];


for ( let i = 0; i <= products.length - 1; i++) { if (products[i].price <= 100) {
  cheap.push(products[i]);}

  let frase = `Total price for ${cheap.product} is ${cheap.price}!`;
}

  console.log(cheap);

  
for ( let i = 0; i <= products.length - 1; i++) { if (products[i].price >= 101 && products[i].price <= 500 ) {
  normal.push(products[i]);}}

  console.log(normal);

for ( let i = 0; i <= products.length - 1; i++) { if (products[i].price >= 501 && products[i].price <= 3000 ) {
  expensive.push(products[i]);}}

  console.log(expensive);

for ( let i = 0; i <= products.length - 1; i++) { if (products[i].price >= 3001) {
  moreExpensive.push(products[i]);}}

  console.log(moreExpensive);


for ( let i = 0; i <= products.length - 1; i++) { if (products[i].price <= 100) {
  cheap.push(products[i]);}}

  cheapSum = cheap {
    function getSum(total, num) {
    
     return total + Math.round(num);
  }

  console.log(numbers.reduce(getSum, 0));
  }

  console.log(cheap);




//sumirane

function getSum(total, num) {
  return total + Math.round(num);
}

console.log(numbers.reduce(getSum, 0));





  //task 5

  let students = [
    { name: "Ivan", score: 5 },
    { name: "Dimitar", score: 5.5 },
    { name: "Kristian", score: 4 },
    { name: "Valentin", score: 6 },
    { name: "Veselin", score: 3 },
    { name: "Genadi", score: 5 },
    { name: "Yavor", score: 3 },
    { name: "Marin", score: 5.5 },
    { name: "Kalin", score: 3 },
    { name: "Yavor", score: 6 }
];

let excellent = [];

for ( let i = 0; i <= students.length - 1; i++) {
  if ( students[i].score >= 5.5) {
    excellent.push(students[i]);
  }
}


// task 6 - Fibbonacci numbers

let i;
let fib = []; 

fib[0] = 0;
fib[1] = 1;
for (i = 2; i <= 14; i++) {
  fib[i] = fib[i - 2] + fib[i - 1];

  console.log(fib);
} 


// while

function fibo(n) {
    const fiboLine = [0, 1];
    while (fiboLine.length - 1 < n) fiboLine.push(fiboLine.at(-2) + fiboLine.at(-1));
    fiboLine.length = n; 
    return fiboLine;
}

console.log(fibo(15));




